# FlowyMc | Staff Applications

موقع تقديم عربي/إنجليزي لرتبة Trial، يرسل الطلبات إلى قناة Discord عبر Webhook من جهة الخادم.

## التشغيل محلياً
1. ثبّت Node.js 18 أو أحدث.
2. فك ضغط المشروع وافتح الطرفية داخل المجلد.
3. نفّذ: `npm install`
4. انسخ `.env.example` إلى ملف باسم `.env`.
5. ضع رابط Webhook **الجديد** في `DISCORD_WEBHOOK_URL` داخل `.env`.
6. نفّذ: `npm start`
7. افتح `http://localhost:3000`

## النشر
ارفع المشروع إلى استضافة تدعم Node.js، واضبط متغير البيئة `DISCORD_WEBHOOK_URL` من لوحة الاستضافة، ثم شغّل `npm start`.

## حماية مهمة
- لا تضع رابط Webhook داخل ملفات `public` أو JavaScript أو HTML.
- لا ترفع ملف `.env` إلى GitHub ولا ترسله لأحد.
- رابط Webhook الذي تم نشره في المحادثة يجب حذفه وإعادة إنشائه من Discord قبل الاستخدام.
- استخدم HTTPS عند نشر الموقع، وأضف حماية من الإرسال المتكرر (rate limiting) قبل فتحه للعامة.
