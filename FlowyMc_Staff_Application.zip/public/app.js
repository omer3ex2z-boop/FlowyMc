const form = document.getElementById("application");
const statusBox = document.getElementById("status");
const langButton = document.getElementById("language");
let lang = "ar";
document.getElementById("year").textContent = new Date().getFullYear();

function setLanguage(next) {
  lang = next;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-ar][data-en]").forEach(el => {
    el.innerHTML = el.dataset[lang];
  });
  langButton.textContent = lang === "ar" ? "English" : "العربية";
  statusBox.textContent = "";
}
langButton.addEventListener("click", () => setLanguage(lang === "ar" ? "en" : "ar"));

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = form.querySelector(".submit");
  button.disabled = true;
  statusBox.className = "status";
  statusBox.textContent = lang === "ar" ? "جارٍ إرسال طلبك..." : "Sending your application...";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error("send failed");
    statusBox.textContent = lang === "ar" ? "تم إرسال طلبك بنجاح! بالتوفيق." : "Your application was sent successfully. Good luck!";
    form.reset();
  } catch {
    statusBox.className = "status error";
    statusBox.textContent = lang === "ar"
      ? "تعذر الإرسال. تأكد من إعداد Webhook على الاستضافة ثم حاول مجدداً."
      : "Could not send. Check the webhook configuration on your host and try again.";
  } finally {
    button.disabled = false;
  }
});