require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/apply", async (req, res) => {
  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) return res.status(503).json({ error: "Webhook is not configured." });

  const fields = ["player", "age", "discord", "experience", "motivation", "scenario"];
  const data = {};
  for (const key of fields) {
    const value = String(req.body[key] || "").trim();
    if (!value || value.length > 1200) {
      return res.status(400).json({ error: "Please complete all fields." });
    }
    data[key] = value;
  }

  const embed = {
    title: "New Trial Staff Application | تقديم جديد لرتبة Trial",
    color: 5793266,
    fields: [
      { name: "Minecraft username | اسم اللاعب", value: data.player, inline: true },
      { name: "Age | العمر", value: data.age, inline: true },
      { name: "Discord", value: data.discord, inline: true },
      { name: "Experience | الخبرة", value: data.experience },
      { name: "Why FlowyMc? | لماذا FlowyMc؟", value: data.motivation },
      { name: "Scenario | موقف إداري", value: data.scenario }
    ],
    footer: { text: "FlowyMc Staff Applications" },
    timestamp: new Date().toISOString()
  };

  try {
    const response = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ embeds: [embed] })
    });
    if (!response.ok) throw new Error("Discord webhook request failed");
    res.json({ ok: true });
  } catch {
    res.status(502).json({ error: "Could not send the application to Discord." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`FlowyMc application site running on port ${port}`));